@extends('layouts.app')

@section('content')
    @livewire('index')
@endsection
